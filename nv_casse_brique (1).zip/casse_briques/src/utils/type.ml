type pos = Left | Middle | Right
type nature = Player of pos | Block | Ball | Wall
