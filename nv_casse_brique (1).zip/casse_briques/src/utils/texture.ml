type t = 
    Color of Gfx.color
  | Surface of Gfx.surface

